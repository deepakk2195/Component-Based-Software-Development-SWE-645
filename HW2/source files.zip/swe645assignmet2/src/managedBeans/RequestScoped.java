package managedBeans;

public @interface RequestScoped {

}
